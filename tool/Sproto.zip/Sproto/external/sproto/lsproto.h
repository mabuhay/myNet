#ifndef __LUA_LSPROTO_H_
#define __LUA_LSPROTO_H_

#if __cplusplus
extern "C" {
#endif

#include "lauxlib.h"

int luaopen_sproto_core(lua_State *L);

#if __cplusplus
}
#endif

#endif